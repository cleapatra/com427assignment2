<?php
  $conn = mysqli_connect ("localhost", "B00642652", "bDmwDSc0")
    or die ("Could not connect:" . mysqli_error ($conn));
   

mysqli_select_db($conn, 'B00642652') OR DIE ('Database will not open');


$query = "SELECT * FROM member";
$result = mysqli_query ($conn, $query) or die ("Invalid query");


mysqli_close($conn);   
     
     
     
     ?>